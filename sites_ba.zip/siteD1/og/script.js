 
// JavaScript to simulate meme refresh
document.getElementById('refresh-meme').addEventListener('click', function() {
    const meme = document.querySelector('.meme');
    meme.src = `https://via.placeholder.com/300x200.png?text=New+Meme+${Math.floor(Math.random() * 100)}`;
});
