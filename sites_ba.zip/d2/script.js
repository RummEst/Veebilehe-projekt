 
// Carousel functionality
let currentSlide = 0;
const slides = document.querySelectorAll(".carousel-item");

document.querySelector(".next").addEventListener("click", () => {
    slides[currentSlide].classList.remove("active");
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].classList.add("active");
});

document.querySelector(".prev").addEventListener("click", () => {
    slides[currentSlide].classList.remove("active");
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    slides[currentSlide].classList.add("active");
});

// Filter functionality
function filterContent(category) {
    const cards = document.querySelectorAll(".card");
    cards.forEach(card => {
        if (category === 'all' || card.classList.contains(category)) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
}
